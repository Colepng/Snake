# # Python3 code to convert a tuple
# # into a string using a for loop


# # def convertTuple(tup):
# # 		# initialize an empty string
# # 	str = ''
# # 	for item in tup:
# # 		str = str + item
# # 	return str


# # Driver code
# tuple = (0,0,255)
# print(str(tuple))
# # str = convertTuple(tuple)
# # print(str)

# def count_positives_sum_negatives(arr):
#     if arr == None: return []
#     num_of_pos = 0
#     sum_of_neg = 0
#     for i in arr:
#         if arr[i] > 0:
#             num_of_pos += 1
#         elif arr[i] < 0:
#             sum_of_neg += arr[i]

#     return [num_of_pos,sum_of_neg]
# for i in range(len(sentance))
# "a23e".count(['a', 'e', 'i', 'o', 'u'])