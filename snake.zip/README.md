# Snake
Snake made in python



resouces

    How to draw text 
        https://www.geeksforgeeks.org/python-display-text-to-pygame-window/
        https://stackoverflow.com/questions/20842801/how-to-display-text-in-pygame
        https://www.pygame.org/docs/ref/font.html#pygame.font.Font.render

    How to get a value from a tuple 
        https://stackoverflow.com/questions/3136059/getting-one-value-from-a-tuple

    How to read/write to a json file
        https://www.w3schools.com/js/js_json_syntax.asp
        https://www.w3schools.com/python/python_json.asp
        https://github.com/Colepng/Frcdiscordbot/commit/109f93f86a92246f9ae24459322e14886273755e
        https://pythonbasics.org/read-json-file/
        https://stackabuse.com/reading-and-writing-json-to-a-file-in-python/

    Text input with pygame
        https://www.geeksforgeeks.org/how-to-create-a-text-input-box-with-pygame/

    How to check a varivles type
        https://www.delftstack.com/howto/python/python-check-variable-type/#:~:text=variable%20in%20Python.-,Use%20the%20type()%20Function%20to%20Check%20Variable%20Type%20in,return%20the%20variable%20data%20type.

    Sockets and server stuff
        https://stackoverflow.com/questions/27241804/sending-a-file-over-tcp-sockets-in-python
        https://stackoverflow.com/questions/43420075/python-socket-not-receiving-without-sending
        https://www.thepythoncode.com/article/send-receive-files-using-sockets-python
        https://python.readthedocs.io/en/stable/howto/sockets.html
        https://stackoverflow.com/questions/18669064/send-additional-arguments-through-socket-sendto
        https://stackoverflow.com/questions/48832303/python-socket-server-with-arguments
        https://www.biob.in/2018/04/simple-server-and-client-chat-using.html
        https://www.geeksforgeeks.org/simple-chat-room-using-python/
        https://stackoverflow.com/questions/1259084/what-encoding-code-page-is-cmd-exe-using
        https://www.educative.io/edpresso/how-to-convert-strings-to-bytes-in-python
        https://www.bogotobogo.com/python/python_network_programming_tcp_server_client_chat_server_chat_client_select.php
        https://stackoverflow.com/questions/166506/finding-local-ip-addresses-using-pythons-stdlib
        https://www.codespeedy.com/how-to-check-the-internet-connection-in-python/

    import stucture 
        https://stackoverflow.com/questions/6523791/why-is-python-running-my-module-when-i-import-it-and-how-do-i-stop-it

    SQL
        https://www.w3schools.com/sql/sql_insert.asp
        https://stackoverflow.com/questions/10900609/need-to-add-values-into-existing-rows-and-columns

