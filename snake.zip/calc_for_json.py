def calc_in_grid(num_to_round, grid_size):
    return round(num_to_round/grid_size)*grid_size