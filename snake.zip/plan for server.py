if offline only write to local database



if online and played offline

read changes of local database send changes to online database


if online 

send changes to online database and local database



